<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>keyword bank</title>
	<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css"); ?>">
	<link href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/bootstrap/css/box.css')?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/datatables/css/dataTables.bootstrap.css')?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/bootstrap/css/new.css')?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/datatables/css/dataTables.bootstrap.css')?>" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-default" role="navigation">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="<?php echo base_url(); ?>index.php/home">KeyWord Bank</a>
		</div>
		<div class="collapse navbar-collapse" id="navbar1">
			<ul class="nav navbar-nav navbar-right">
				<?php if ($this->session->userdata('login')){ ?>
				<li><p class="navbar-text">Hello <?php echo $this->session->userdata('uname'); ?></p></li>
				<li><a href="<?php echo base_url(); ?>index.php/home/logout">Log Out</a></li>
				<?php } else { ?>
				<li><a href="<?php echo base_url(); ?>index.php/login">Login</a></li>
				<?php } ?>
			</ul>
		</div>
	</div>
</nav>

<form method="post">
<input type="text" id="keyword" placeholder="Enter keyword"/>
<input type="button" id="submit" onclick="save();" value="save" />
</form>
<br>
<div class="box">
    <h1>Keywords</h1>
    <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="10%">
      <thead>
        <tr>
					<th>ID</th>
					<th>keyword</th>
          <th style="width:12px;">Action
          </th>
        </tr>
      </thead>
      <tbody>
				<?php foreach($key as $k){?>
				     <tr>
				         <td><?php echo $k->kid;?></td>
				         <td><?php echo $k->keyword;?></td>
								 																<td>
									<button class="btn btn-warning" onclick="edit_users(<?php echo $k->kid;?>)"><i class="glyphicon glyphicon-pencil"></i></button>
								</td>
				      </tr>
				     <?php }?>
      </tbody>
    </table>
  </div>
	<br>
	<br>
	<br>
<div class="container">
	<div class="left-div left-text">
		<div class="something">
		 Keywords <input name="search_data" id="search_data" type="text" placeholder="Search" onkeyup="ajaxSearch();"/>
		     <div id="suggestions">
					 <br/>
					 <br/>
					 <div class="row">

 <div class="col-sm-12">
	 <ul class="list-group">
	 <div id="autoSuggestionsList" >
	 </div>
	</ul>
 </div>
</div>

		     </div>
		</div>
	</div>
	<div class="right-div right-text">
		<h3>Favourites</h3>
	</div>
</div>
</div>
<h3>Trending Keywords</h3>
<div class="container">

	<div>


		<script src="<?php echo base_url('assets/jquery/jquery-3.1.0.min.js')?>"></script>
  <script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js')?>"></script>
  <script src="<?php echo base_url('assets/datatables/js/jquery.dataTables.min.js')?>"></script>
  <script src="<?php echo base_url('assets/datatables/js/dataTables.bootstrap.js')?>"></script>

<script type="text/javascript">

function save()
{

   var keyword = $("#keyword").val();
	 var key = {keyword: keyword};
	 // ajax adding data to database
			$.ajax({
				url : "<?php echo ('http://localhost/ci/index.php/Key/key_add')?>",
				type: "POST",
				data: key,
				dataType: "JSON",
				success: function(data)
				{
					 //if success close modal and reload ajax table
					// $('#modal_form').modal('hide');
					location.reload();// for reload a page
				},
				error: function (jqXHR, textStatus, errorThrown)
				{
						alert('Error adding data');
				}
		});

}

function ajaxSearch() {
            var input_data = $('#search_data').val();
            if (input_data.length === 0) {
                $('#suggestions').hide();
            } else {

                var post_data = {
                    'search_data': input_data,
                    '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
                };

                $.ajax({
                    type: "POST",
                    url: "<?php echo ('http://localhost/ci/index.php/Search/autocomplete')?>",
                    data: post_data,
                    success: function(data) {
                        // return success
                        if (data.length > 0) {
                            $('#suggestions').show();
                            $('#autoSuggestionsList').addClass('auto_list');
                            $('#autoSuggestionsList').html(data);
                        }
                    }
                });

            }
        }

				function fav(kid)
                {
                    //alert('you have placed an order');
                  //  location.reload();
                    var url;
                    url = "<?php echo ('http://localhost/ci/index.php/Fav/fav') ?>/" + kid;
                    // ajax adding data to database
                    $.ajax({
                        url: url,
                        type: "GET",
                        //data: "",
                        //dataType: "JSON",
                        success: function (data)
                        {
                            //if success close modal and reload ajax table
                            //$('#modal_form').modal('hide');
                            //location.reload();// for reload a page
                            //alert("success");
                        },
                        error: function (jqXHR, textStatus, errorThrown)
                        {
//                alert('Error adding / update data');
                        }
                    });
                }


</script>
<script type="text/javascript" src="<?php echo base_url("assets/js/jquery-1.10.2.js"); ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/js/bootstrap.js"); ?>"></script>

</body>
</html>
