<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Search extends CI_Controller {

	 public function __construct()
	 	{
	 		parent::__construct();
			$this->load->helper('url');
	 		//$this->load->model('Search_model');
	 	}

  public function key()
	{
		$this->load->model('Key_model');
		$data['key']=$this->load->Key_model->get_all_keywords();
   $this->load->view('profile_view',$data);
	}

    public function autocomplete()
  {
       // load model
      $this->load->model('Search_model');

       $search_data = $this->input->post('search_data');

       $result = $this->Search_model->get_autocomplete($search_data);

       if (!empty($result))
       {
            foreach ($result as $row):
                 echo "<li class='list-group-item'>" . $row->keyword . "<span id='myLikeBtn' onclick='fav();' class='badge'><i class='glyphicon glyphicon-star-empty'></i></span></li>";

            endforeach;
       }
       else
       {
             echo "<li class='list-group-item'>No matching Keyword found</li>";
       }
   }

}
