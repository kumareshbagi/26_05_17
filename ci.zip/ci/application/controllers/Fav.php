<?php
class Fav extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('url','html'));
		$this->load->library('session');
		$this->load->database();
		$this->load->model('Fav_model');
		//$this->load->model('Key_model');
	}

  function fav($kid) {
       //$uid=$this->session->userdata('uid');
       $data = array(
           'kid' => $kid,
           'flag' => '1',
       );
       $insert = $this->Fav_model->fav_add($data);
       echo json_encode(array("status" => TRUE));

       $det['tot_vote'] = $this->Fav_model->get_total_likes1();
       //echo $det['tot_vote'];
       $data['count'] = $det['tot_vote'];
       $this->load->view('profile_view', $data);
   }

}
?>
