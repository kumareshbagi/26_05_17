<?php
class profile extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('url','html'));
		$this->load->library('session');
		$this->load->database();
		//$this->load->model('user_model');
		$this->load->model('Key_model');
		//$this->load->model('Key_model');
	}

	function index()
	{

		$data['key']=$this->Key_model->get_all_keywords();
		$this->load->view('profile_view', $data);
		//$this->load->key();
	}

}
?>
