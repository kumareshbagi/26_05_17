<?php
class K1 extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form','url','html'));
		$this->load->library(array('session', 'form_validation'));
		$this->load->database();
		
	}
    public function index()
    {
		$data['keyword']=$this->K1_model->get_all_keywords();
		$this->load->view('key_view',$data);
    }
}
?>
