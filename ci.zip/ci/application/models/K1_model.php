<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class K1_model extends CI_Model
{

	var $table = 'keyword';


	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function get_all_keywords()
	{
	$this->db->from('keyword');
	$query=$this->db->get();
	return $query->result();
	}

	public function key_add($data)
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}


}
?>
